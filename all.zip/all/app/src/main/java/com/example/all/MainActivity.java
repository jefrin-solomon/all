package com.example.all;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button toast,status,alert,btnprog,date,next;
    EditText e;

    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toast = findViewById(R.id.toast);
        status=findViewById(R.id.status);
        alert=findViewById(R.id.alert);
        btnprog=findViewById(R.id.progress);
        date = findViewById(R.id.date);
        e=findViewById(R.id.test);
        next = findViewById(R.id.next);

        toast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Toast button is clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), menus.class);
                startActivity(intent);
            }


        });



        String channelId = "my_channel_id";
        String channelName = "My Channel";
        int importance = NotificationManager.IMPORTANCE_HIGH;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, channelId)
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentTitle("My Notification")
                        .setContentText("Status notification button has been clicked")
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

//                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivityHome.this);
//                managerCompat.notify(1, builder.build());

                NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager.notify(001, builder.build());
            }
        });


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Alert Dialog");
                builder.setMessage("Are you sure you want to visit this page?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked Yes button
                        Toast.makeText(MainActivity.this, "you have clicked yes", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked No button
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });


        ProgressDialog progress=new ProgressDialog(this);
        btnprog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //////////////////////////////Progress bar

                progress.setMessage("Downloading Music");
                progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                // progress.setIndeterminate(true);
                progress.setProgress(0);
                progress.show();
                final int totalProgressTime = 100;
                final Thread t = new Thread() {
                    @Override
                    public void run() {
                        int jumpTime = 0;
                        while(jumpTime < totalProgressTime) {
                            try {
                                Thread.sleep(200);
                                jumpTime += 5;
                                progress.setProgress(jumpTime);
                            } catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }progress.dismiss();
                        if (jumpTime == totalProgressTime) {
                            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivity(takePictureIntent);
                            //Toast.makeText(MainActivity.this, "Progress completed", Toast.LENGTH_SHORT).show();
                        }

                    }

                };

                t.start();


            }
        });

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                Toast.makeText(MainActivity.this, hourOfDay + ":" + minute, Toast.LENGTH_LONG).show();
                                e.setText(hour+":"+minute);
                            }
                        }, hour, minute, false);
                timePickerDialog.show();

            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), intents.class);
                startActivity(intent);
            }
        });



    }
}