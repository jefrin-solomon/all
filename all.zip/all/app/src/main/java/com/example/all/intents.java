package com.example.all;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

public class intents extends AppCompatActivity {

    Button camera,phone,email,browser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intents);

        camera = findViewById(R.id.cbutton);
        phone = findViewById(R.id.pbutton);
        email = findViewById(R.id.ebutton);
        browser = findViewById(R.id.wbutton);

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(takePictureIntent);
            }
        });

        browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.google.com/webhp?hl=en&sa=X&ved=0ahUKEwigsafcmcn9AhWFAbcAHdNWCcoQPAgI"));
                startActivity(intent);
            }
        });

        phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dial = new Intent(Intent.ACTION_DIAL);
                dial.setData(Uri.parse("tel: +916381717874"));
                startActivity(dial);
            }
        });

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent dial = new Intent(Intent.ACTION_SEND);
//                dial.setType("message/rfc822");
//                dial.putExtra(Intent.EXTRA_EMAIL,new String[]{"harikrishnantce@gmail.com","abc@gmail.com"});
//                dial.putExtra(Intent.EXTRA_SUBJECT,"Queries");
//                dial.putExtra(Intent.EXTRA_TEXT,"please solve this");
//                startActivity(Intent.createChooser(dial,"Email via"));
                Intent i = new Intent(getApplicationContext(),LocationPage.class);
                startActivity(i);




            }
        });



    }
}