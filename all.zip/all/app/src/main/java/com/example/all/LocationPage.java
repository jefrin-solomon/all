package com.example.all;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;

public class LocationPage extends AppCompatActivity {

    EditText ed1;
    Button b2;
    TextView txtLat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        txtLat = findViewById(R.id.textView);
        Geocoder gc = new Geocoder(getApplicationContext());
        if (gc.isPresent()) {
            List<Address> list = null;
            try {
                list = gc.getFromLocationName("Thiagarajar College of Enginnering,Madurai 625015", 1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Address address = list.get(0);
            double lat = address.getLatitude();
            double lng = address.getLongitude();
            txtLat.setText(String.valueOf(lat));
        }


    }
}