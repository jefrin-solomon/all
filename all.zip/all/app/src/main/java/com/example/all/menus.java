package com.example.all;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

public class menus extends AppCompatActivity {

    Button pop,con;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menus);

        pop=findViewById(R.id.popbtn);
        con = findViewById(R.id.conbtn);
        registerForContextMenu(con);


        pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(menus.this, view);
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu_item_1:
                                // Handle menu item 1 click
                                Toast.makeText(menus.this, "selected", Toast.LENGTH_SHORT).show();
                                return true;
                            case R.id.menu_item_2:
                                // Handle menu item 2 click
                                return true;
                            case R.id.menu_item_3:
                                // Handle menu item 3 click
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                popupMenu.show();



            }
        });


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item_1:
                // Handle menu item 1 click
                Toast.makeText(this, "Iem1 selected ", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_item_2:
                // Handle menu item 2 click
                return true;
            case R.id.menu_item_3:
                // Handle menu item 3 click
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item_1:
                // Handle menu item 1 click
                Toast.makeText(this, "Selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_item_2:
                // Handle menu item 2 click
                return true;
            case R.id.menu_item_3:
                // Handle menu item 3 click
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

}